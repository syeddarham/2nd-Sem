class q4{
public static void main(String[] args) {
    Course course = new Course();
    course.setCourseCode("NS101");
    course.setCourseName("Applied Physics");
    course.setCreditHours(3);
    course.displayCourseDetails();
    course.setCourseCode("MT1003"); 
    course.setCourseName("CALCULUS");
    course.setCreditHours(5);
}} 